package com.example.voicelock

import android.accessibilityservice.AccessibilityService
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.*
import android.speech.*
import android.widget.Toast

class VoiceService : Service() {
    private var sr: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private var running = false
    private val wake = Regex("""(?:hey|hi|a|ok)\s+(?:moto|motto|motor|moto's)\s*,?\s*(.*)""")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("v", "Voice", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "v").setContentTitle("Listening for “Hey Moto”")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        if (!running) { running = true; listen() }
        return START_STICKY
    }

    private fun listen() {
        if (!running) return
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle) {
                    b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull { handle(it) }
                    again()
                }
                override fun onError(e: Int) = again()
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            })
        }
    }

    private fun again() { h.postDelayed({ listen() }, 250) }

    private fun act(a: Int) = LockService.instance?.performGlobalAction(a)
        ?: run { toast("Enable Voice Lock in Accessibility"); false }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun handle(raw: String): Boolean {
        val cmd = wake.find(raw.lowercase())?.groupValues?.get(1)?.trim() ?: return false
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        when {
            "lock" in cmd -> act(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
            "flashlight" in cmd || "torch" in cmd -> {
                val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
                cm.setTorchMode(cm.cameraIdList[0], "off" !in cmd)
            }
            "volume up" in cmd -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            "volume down" in cmd -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            "home" in cmd -> act(AccessibilityService.GLOBAL_ACTION_HOME)
            "back" in cmd -> act(AccessibilityService.GLOBAL_ACTION_BACK)
            "recent" in cmd -> act(AccessibilityService.GLOBAL_ACTION_RECENTS)
            cmd.startsWith("open ") -> openApp(cmd.removePrefix("open ").trim())
            else -> return false
        }
        return true
    }

    private fun openApp(name: String) {
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val app = packageManager.queryIntentActivities(q, 0)
            .firstOrNull { it.loadLabel(packageManager).toString().lowercase().contains(name) } ?: return toast("No app: $name")
        packageManager.getLaunchIntentForPackage(app.activityInfo.packageName)
            ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)?.let { startActivity(it) }
    }

    override fun onDestroy() { running = false; sr?.destroy(); super.onDestroy() }
}
