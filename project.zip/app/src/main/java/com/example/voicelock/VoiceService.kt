package com.example.voicelock

import android.accessibilityservice.AccessibilityService
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.*
import android.speech.tts.TextToSpeech
import android.widget.Toast
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar
import java.util.Locale
import java.util.zip.ZipInputStream

class VoiceService : Service() {
    companion object {
        var onLevel: ((Float) -> Unit)? = null
        var onHeard: ((String, Boolean) -> Unit)? = null
        var onStatus: ((String) -> Unit)? = null
        var statusText = ""
        var active = false
        const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
    }

    private val h = Handler(Looper.getMainLooper())
    private var running = false
    private var fired = false
    private var model: Model? = null
    private var ss: SpeechService? = null
    private var tts: TextToSpeech? = null
    private val wake = Regex("""^(?:(?:hey|hi|ok|okay)\s+)?(?:moto|motto|motor|mo to|mother)\b[\s,]*(.*)""")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("v", "Voice", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "v").setContentTitle("J Voice Assistant is listening")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        active = true
        if (!running) { running = true; startEngine() }
        return START_STICKY
    }

    private fun status(s: String) = h.post { statusText = s; onStatus?.invoke(s) }

    // ---------- offline model: download once, then always-on listening ----------
    private fun ensureModel(): File? {
        val dir = File(filesDir, "vosk")
        val done = File(dir, ".done")
        if (!done.exists()) {
            dir.deleteRecursively(); dir.mkdirs()
            val zip = File(filesDir, "m.zip")
            status("Downloading voice model… 0%")
            val c = URL(MODEL_URL).openConnection() as HttpURLConnection
            c.connectTimeout = 15000; c.readTimeout = 30000
            val total = c.contentLength.toLong()
            c.inputStream.use { i ->
                zip.outputStream().use { o ->
                    val buf = ByteArray(65536)
                    var n = 0; var got = 0L; var last = -1
                    while (i.read(buf).also { n = it } > 0) {
                        o.write(buf, 0, n); got += n
                        if (total > 0) {
                            val pc = (got * 100 / total).toInt()
                            if (pc != last && pc % 5 == 0) { last = pc; status("Downloading voice model… $pc%") }
                        }
                    }
                }
            }
            status("Preparing voice model…")
            ZipInputStream(zip.inputStream().buffered()).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    val out = File(dir, e.name)
                    if (!out.canonicalPath.startsWith(dir.canonicalPath)) throw SecurityException("bad zip")
                    if (e.isDirectory) out.mkdirs() else { out.parentFile?.mkdirs(); out.outputStream().use { z.copyTo(it) } }
                    e = z.nextEntry
                }
            }
            zip.delete(); done.createNewFile()
        }
        return dir.listFiles { f -> f.isDirectory }?.firstOrNull()
    }

    private fun startEngine() {
        Thread {
            try {
                val dir = ensureModel() ?: throw IllegalStateException("model folder missing")
                val m = Model(dir.absolutePath)
                h.post { begin(m) }
            } catch (e: Exception) {
                status("Voice model error: ${e.message}. Check internet and tap Start again.")
            }
        }.start()
    }

    private fun begin(m: Model) {
        if (!running) { m.close(); return }
        model = m
        ss = SpeechService(Recognizer(m, 16000f), 16000f).also { it.startListening(listener) }
        status("")
    }

    private fun pulse() { onLevel?.invoke(0.8f); h.postDelayed({ onLevel?.invoke(0f) }, 300) }

    private val listener = object : RecognitionListener {
        override fun onPartialResult(hyp: String?) {
            val t = JSONObject(hyp ?: "{}").optString("partial")
            if (t.isEmpty()) return
            pulse()
            if (!fired && "lock" in t && handle(t)) { fired = true; onHeard?.invoke(t, true) }
        }
        override fun onResult(hyp: String?) {
            val t = JSONObject(hyp ?: "{}").optString("text")
            if (t.isNotEmpty() && !fired) onHeard?.invoke(t, handle(t))
            fired = false
        }
        override fun onFinalResult(hyp: String?) {}
        override fun onError(e: Exception?) { status("Mic error: ${e?.message}") }
        override fun onTimeout() {}
    }

    // ---------- commands ----------
    private fun act(a: Int) = LockService.instance?.performGlobalAction(a)
        ?: run { toast("Enable J Voice Assistant in Accessibility"); false }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun say(s: String) {
        toast(s)
        if (tts == null) {
            tts = TextToSpeech(this) { st ->
                if (st == TextToSpeech.SUCCESS) { tts?.language = Locale("en", "IN"); tts?.speak(s, TextToSpeech.QUEUE_FLUSH, null, "j") }
            }
        } else tts?.speak(s, TextToSpeech.QUEUE_FLUSH, null, "j")
    }

    private fun launch(i: Intent) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); try { (LockService.instance ?: this).startActivity(i) } catch (e: Exception) { toast("Can’t open") } }

    private fun handle(raw: String): Boolean {
        val t = raw.lowercase().trim()
        val m = wake.find(t)
        // "Hey Moto <command>" works for any length; a bare short command (up to 4 words) also works
        val cmd = if (m != null) m.groupValues[1].trim() else if (t.split(" ").size <= 4) t else return false
        if (cmd.isEmpty()) return false
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        when {
            "lock" in cmd -> act(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
            "flashlight" in cmd || "torch" in cmd -> {
                val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
                cm.setTorchMode(cm.cameraIdList[0], "off" !in cmd)
            }
            "volume up" in cmd -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            "volume down" in cmd -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            "home" in cmd -> act(AccessibilityService.GLOBAL_ACTION_HOME)
            "back" in cmd -> act(AccessibilityService.GLOBAL_ACTION_BACK)
            "recent" in cmd -> act(AccessibilityService.GLOBAL_ACTION_RECENTS)
            "battery" in cmd -> say("Battery is " + (getSystemService(Context.BATTERY_SERVICE) as BatteryManager).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) + " percent")
            "what time" in cmd || "time is it" in cmd -> { val c = Calendar.getInstance(); say("It is " + String.format("%d:%02d", c.get(Calendar.HOUR), c.get(Calendar.MINUTE)).replaceFirst("^0:", "12:")) }
            "ride" in cmd || "cab" in cmd || "rapido" in cmd -> openApp("rapido")
            cmd.startsWith("navigate to ") || cmd.startsWith("take me to ") ->
                launch(Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(cmd.substringAfter(" to ")))).setPackage("com.google.android.apps.maps"))
            cmd.startsWith("search for ") || cmd.startsWith("google ") ->
                launch(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, cmd.substringAfter(" for ", cmd.removePrefix("google "))))
            cmd.startsWith("open ") -> openApp(cmd.removePrefix("open ").trim())
            else -> return false
        }
        return true
    }

    private fun openApp(name: String) {
        val key = name.replace(Regex("[^a-z0-9]"), "")
        if (key.isEmpty()) return
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val app = packageManager.queryIntentActivities(q, 0).firstOrNull {
            it.loadLabel(packageManager).toString().lowercase().replace(Regex("[^a-z0-9]"), "").contains(key)
        } ?: return toast("No app: $name")
        packageManager.getLaunchIntentForPackage(app.activityInfo.packageName)?.let { launch(it) }
    }

    override fun onDestroy() {
        running = false; active = false; statusText = ""
        h.removeCallbacksAndMessages(null)
        ss?.stop(); ss?.shutdown(); model?.close(); tts?.shutdown()
        super.onDestroy()
    }
}
