package com.example.voicelock

import android.accessibilityservice.AccessibilityService
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.*
import android.speech.*
import android.widget.Toast

class VoiceService : Service() {
    companion object {
        var onLevel: ((Float) -> Unit)? = null
        var onHeard: ((String, Boolean) -> Unit)? = null
        var active = false
    }

    private var sr: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private var running = false
    private var handled = false
    private val wake = Regex("""^(?:(?:hey|hi|ok|okay)\s+)?(?:moto|motto|motor|mo to)\b[\s,]*(.*)""")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("v", "Voice", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "v").setContentTitle("J Voice Assistant is listening")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        active = true
        if (!running) { running = true; listen() }
        return START_STICKY
    }

    private val listener = object : RecognitionListener {
        override fun onResults(b: Bundle) {
            val l = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            if (!handled && l != null) {
                val ok = l.firstOrNull { handle(it) } != null
                onHeard?.invoke(l.firstOrNull() ?: "", ok)
            }
            next(300)
        }
        override fun onError(e: Int) {
            if (e == 9 || e == 12 || e == 13) toast("Mic error $e")
            when (e) {
                6, 7 -> next(200)
                11, 5, 10 -> { sr?.destroy(); sr = null; next(1500) }
                else -> { sr?.cancel(); next(1000) }
            }
        }
        override fun onRmsChanged(v: Float) { onLevel?.invoke(((v + 2f) / 12f).coerceIn(0f, 1f)) }
        override fun onPartialResults(p: Bundle?) {
            val t = p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
            if (!handled && "lock" in t.lowercase() && handle(t)) {
                handled = true; onHeard?.invoke(t, true); sr?.cancel(); next(600)
            }
        }
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(t: Int, p: Bundle?) {}
    }

    private fun next(ms: Long) { h.postDelayed({ listen() }, ms) }

    private fun listen() {
        if (!running) return
        handled = false
        if (sr == null) sr = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(listener) }
        sr?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        })
    }

    private fun act(a: Int) = LockService.instance?.performGlobalAction(a)
        ?: run { toast("Enable J Voice Assistant in Accessibility"); false }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun handle(raw: String): Boolean {
        val t = raw.lowercase().trim()
        val m = wake.find(t)
        // "Hey Moto <command>" works for any length; a bare short command (up to 4 words) also works
        val cmd = if (m != null) m.groupValues[1].trim() else if (t.split(" ").size <= 4) t else return false
        if (cmd.isEmpty()) return false
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        when {
            "lock" in cmd -> act(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
            "flashlight" in cmd || "torch" in cmd -> {
                val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
                cm.setTorchMode(cm.cameraIdList[0], "off" !in cmd)
            }
            "volume up" in cmd -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            "volume down" in cmd -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            "home" in cmd -> act(AccessibilityService.GLOBAL_ACTION_HOME)
            "back" in cmd -> act(AccessibilityService.GLOBAL_ACTION_BACK)
            "recent" in cmd -> act(AccessibilityService.GLOBAL_ACTION_RECENTS)
            "ride" in cmd || "cab" in cmd || "rapido" in cmd -> openApp("rapido")
            cmd.startsWith("open ") -> openApp(cmd.removePrefix("open ").trim())
            else -> return false
        }
        return true
    }

    private fun openApp(name: String) {
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val app = packageManager.queryIntentActivities(q, 0)
            .firstOrNull { it.loadLabel(packageManager).toString().lowercase().contains(name) } ?: return toast("No app: $name")
        packageManager.getLaunchIntentForPackage(app.activityInfo.packageName)
            ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)?.let { (LockService.instance ?: this).startActivity(it) }
    }

    override fun onDestroy() { running = false; active = false; h.removeCallbacksAndMessages(null); sr?.destroy(); super.onDestroy() }
}
