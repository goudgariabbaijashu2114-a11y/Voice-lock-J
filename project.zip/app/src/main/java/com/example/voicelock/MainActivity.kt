package com.example.voicelock

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48); gravity = Gravity.CENTER_HORIZONTAL }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }.also { l.addView(it) }
        l.addView(TextView(this).apply {
            textSize = 16f
            text = "Say: “Hey Moto, lock the screen”\n\nCommands: lock, flashlight on/off, volume up/down, go home, go back, recent apps, open <app name>\n"
        })
        btn("1. Enable Lock permission (Accessibility)") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("2. Allow microphone + notifications") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        btn("3. Start listening") { startForegroundService(Intent(this, VoiceService::class.java)) }
        btn("Stop listening") { stopService(Intent(this, VoiceService::class.java)) }
        setContentView(l)
    }
}
