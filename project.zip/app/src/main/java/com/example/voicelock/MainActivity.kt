package com.example.voicelock

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class OrbView(c: Context) : View(c) {
    var level = 0f
    var active = false
    private var sm = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(cv: Canvas) {
        val t = System.currentTimeMillis() / 1000.0
        sm += ((if (active) level else 0f) - sm) * 0.2f
        val breathe = (Math.sin(t * 2.0) * 0.03).toFloat()
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(width, height) * 0.28f * (1f + breathe + sm * 0.35f)
        val glow = if (active) 0x553B6CFF else 0x22FFFFFF
        p.shader = RadialGradient(cx, cy, r * 1.9f, intArrayOf(glow, 0x00000000), null, Shader.TileMode.CLAMP)
        cv.drawCircle(cx, cy, r * 1.9f, p)
        val c1 = if (active) 0xFF8AB4FF.toInt() else 0xFF5B6475.toInt()
        val c2 = if (active) 0xFF2F5BEA.toInt() else 0xFF2A2F3C.toInt()
        val c3 = if (active) 0xFF7B3FE4.toInt() else 0xFF171A22.toInt()
        p.shader = RadialGradient(cx - r * 0.3f, cy - r * 0.35f, r * 1.4f,
            intArrayOf(c1, c2, c3), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        cv.drawCircle(cx, cy, r, p)
        postInvalidateOnAnimation()
    }
}

class MainActivity : AppCompatActivity() {
    private lateinit var orb: OrbView
    private lateinit var status: TextView
    private lateinit var heard: TextView
    private lateinit var info: TextView
    private lateinit var toggle: Button
    private val h = Handler(Looper.getMainLooper())

    private fun dp(i: Int) = (i * resources.displayMetrics.density).toInt()
    private fun pill(c: Int) = GradientDrawable().apply { cornerRadius = dp(28).toFloat(); setColor(c) }
    private fun txt(size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        textSize = size; setTextColor(color); gravity = Gravity.CENTER
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }
    private fun btn(t: String, c: Int, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(0xFFFFFFFF.toInt()); background = pill(c)
        setOnClickListener { f() }
    }
    private fun micOk() = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    private fun askPerms() = requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(48), dp(20), dp(24))
        }
        root.addView(txt(20f, 0xFFFFFFFF.toInt(), true).apply { text = "J Voice Assistant" })
        status = txt(14f, 0xFF8A93A8.toInt()).apply { setPadding(0, dp(6), 0, 0) }
        root.addView(status)
        orb = OrbView(this)
        root.addView(orb, LinearLayout.LayoutParams(-1, 0, 1f))
        heard = txt(18f, 0xFFFFFFFF.toInt()).apply { minLines = 2 }
        root.addView(heard)
        info = txt(12f, 0xFF8A93A8.toInt()).apply { setPadding(0, dp(12), 0, dp(12)) }
        root.addView(info)
        toggle = btn("Start listening", 0xFF2F5BEA.toInt()) {
            if (!micOk()) askPerms()
            else if (VoiceService.active) stopService(Intent(this, VoiceService::class.java))
            else startForegroundService(Intent(this, VoiceService::class.java))
            h.postDelayed({ refresh() }, 400)
        }
        root.addView(toggle, LinearLayout.LayoutParams(-1, dp(56)))
        val row = LinearLayout(this).apply { setPadding(0, dp(10), 0, 0) }
        row.addView(btn("Lock permission", 0xFF262B3A.toInt()) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
            LinearLayout.LayoutParams(0, dp(48), 1f).apply { rightMargin = dp(6) })
        row.addView(btn("Mic permission", 0xFF262B3A.toInt()) { askPerms() },
            LinearLayout.LayoutParams(0, dp(48), 1f).apply { leftMargin = dp(6) })
        root.addView(row)
        val frame = android.widget.FrameLayout(this)
        frame.addView(android.widget.ImageView(this).apply {
            setImageResource(R.drawable.bg_photo); scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
        }, android.widget.FrameLayout.LayoutParams(-1, -1))
        frame.addView(View(this).apply { setBackgroundColor(0xD90B0D12.toInt()) }, android.widget.FrameLayout.LayoutParams(-1, -1))
        frame.addView(root, android.widget.FrameLayout.LayoutParams(-1, -1))
        setContentView(frame)
    }

    private fun refresh() {
        val on = VoiceService.active
        orb.active = on
        toggle.text = if (on) "Stop listening" else "Start listening"
        toggle.background = pill(if (on) 0xFFD64545.toInt() else 0xFF2F5BEA.toInt())
        status.text = if (on) (if (VoiceService.statusText.isNotEmpty()) VoiceService.statusText else "Listening… say “lock screen”") else "Tap Start to begin"
        info.text = "Lock permission: " + (if (LockService.instance != null) "ON ✓" else "OFF ✗") +
            "   ·   Mic: " + (if (micOk()) "ON ✓" else "OFF ✗")
    }

    override fun onResume() {
        super.onResume()
        VoiceService.onLevel = { orb.level = it }
        VoiceService.onStatus = { refresh() }
        VoiceService.onHeard = { t, ok ->
            heard.text = "“$t”"
            status.text = if (ok) "Done ✓" else "Didn’t catch a command. Try “Hey Moto, lock the screen”"
        }
        refresh()
    }

    override fun onPause() {
        VoiceService.onLevel = null
        VoiceService.onStatus = null
        VoiceService.onHeard = null
        super.onPause()
    }
}
