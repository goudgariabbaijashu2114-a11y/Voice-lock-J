package com.example.voicelock

import android.accessibilityservice.AccessibilityService
import android.app.Activity
import android.os.Bundle
import android.widget.Toast

class LockActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val s = LockService.instance
        if (s == null) Toast.makeText(this, "Enable Voice Lock in Accessibility first", Toast.LENGTH_LONG).show()
        else s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
        finish()
    }
}
