package com.jashu.editing

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private val Ink = Color(0xFFF4EFE9)
private val Mute = Color(0xFFC9D4D8)
private val Accent = Color(0xFFE0813A)
private val AccentInk = Color(0xFF1A0E05)
private val Panel = Color(0xAA0A0808)
private val TitleFont = FontFamily(Typeface.create("sans-serif-condensed", Typeface.BOLD))

private enum class Screen { Home, Working, Result }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { JashuApp() }
    }
}

@Composable
private fun JashuApp() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var screen by remember { mutableStateOf(Screen.Home) }
    var stage by remember { mutableStateOf("") }
    var before by remember { mutableStateOf<Bitmap?>(null) }
    var after by remember { mutableStateOf<Bitmap?>(null) }
    var full by remember { mutableStateOf<Bitmap?>(null) }
    var kind by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var pending by remember { mutableStateOf<Uri?>(null) }
    var saving by remember { mutableStateOf(false) }

    fun process(uri: Uri) {
        screen = Screen.Working
        error = null
        stage = "Opening your photo"
        scope.launch {
            try {
                val res = withContext(Dispatchers.Default) { PhotoEnhancer.run(ctx, uri) { stage = it } }
                before = res.before; after = res.after; full = res.full; kind = res.kind
                screen = Screen.Result
            } catch (e: Throwable) {
                error = "This photo could not be edited. Try another one."
                screen = Screen.Home
            }
        }
    }

    val takePicture = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) pending?.let { process(it) }
    }
    fun launchCamera() {
        val dir = File(ctx.cacheDir, "images").apply { mkdirs() }
        val f = File.createTempFile("capture_", ".jpg", dir)
        val u = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
        pending = u
        takePicture.launch(u)
    }
    val camPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) launchCamera() else error = "Allow camera access to take photos, or choose one from your gallery."
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) process(uri)
    }
    val onTake = {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) launchCamera()
        else camPerm.launch(Manifest.permission.CAMERA)
    }
    val onPick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }

    BackHandler(enabled = screen == Screen.Result) { screen = Screen.Home }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Image(
            painterResource(R.drawable.home_bg), null,
            Modifier.fillMaxSize(), contentScale = ContentScale.Crop
        )
        when (screen) {
            Screen.Home -> HomeScreen(error, onTake, onPick)
            Screen.Working -> WorkingScreen(stage)
            Screen.Result -> ResultScreen(
                before, after, kind, saving,
                onNew = { screen = Screen.Home },
                onSave = {
                    full?.let { bmp ->
                        saving = true
                        scope.launch {
                            val ok = withContext(Dispatchers.IO) { saveToGallery(ctx, bmp) }
                            saving = false
                            Toast.makeText(
                                ctx,
                                if (ok) "Saved to Pictures/Jashu Editing App" else "Could not save the photo",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                }
            )
        }
    }
}

@Composable
private fun HomeScreen(error: String?, onTake: () -> Unit, onPick: () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(
                listOf(Color.Black.copy(0.4f), Color.Transparent, Color.Transparent, Color.Black.copy(0.65f))
            )
        )
    )
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(24.dp)) {
        Spacer(Modifier.height(36.dp))
        Text(
            "Jashu\nEditing\nApp",
            style = TextStyle(
                fontFamily = TitleFont, fontSize = 78.sp, lineHeight = 76.sp, color = Ink,
                shadow = Shadow(Color.Black, Offset(0f, 3f), 18f)
            )
        )
        Spacer(Modifier.height(14.dp))
        Text(
            "Take a photo. It’s enhanced automatically in up to 4K. No prompts to write.",
            color = Mute, fontSize = 17.sp, lineHeight = 24.sp,
            style = TextStyle(shadow = Shadow(Color.Black, Offset(0f, 2f), 10f)),
            modifier = Modifier.fillMaxWidth(0.8f)
        )
        Spacer(Modifier.weight(1f))
        if (error != null) {
            Text(error, color = Ink, fontSize = 14.sp, modifier = Modifier.padding(bottom = 12.dp))
        }
        Button(
            onClick = onTake, shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = AccentInk),
            modifier = Modifier.fillMaxWidth().height(58.dp)
        ) { Text("Take a photo", fontSize = 17.sp) }
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = onPick, shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Panel, contentColor = Ink),
            modifier = Modifier.fillMaxWidth().height(58.dp)
        ) { Text("Choose from gallery", fontSize = 17.sp) }
        Spacer(Modifier.height(12.dp))
        Text(
            "Faces stay yours. Edits only fix light, colour and detail. Nothing is added, swapped or smoothed away.",
            color = Mute, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun WorkingScreen(stage: String) {
    val t = rememberInfiniteTransition(label = "spin")
    val angle by t.animateFloat(0f, 360f, infiniteRepeatable(tween(1100, easing = LinearEasing), RepeatMode.Restart), label = "a")
    Box(Modifier.fillMaxSize().background(Color.Black.copy(0.68f)), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Canvas(Modifier.size(96.dp)) {
                val sw = 7.dp.toPx()
                drawCircle(Color.White.copy(0.15f), style = Stroke(sw))
                drawArc(
                    Accent, angle, 100f, false,
                    topLeft = Offset(sw / 2, sw / 2),
                    size = Size(size.width - sw, size.height - sw),
                    style = Stroke(sw, cap = StrokeCap.Round)
                )
            }
            Spacer(Modifier.height(24.dp))
            Text("Editing your photo", color = Ink, fontSize = 20.sp)
            Spacer(Modifier.height(6.dp))
            Text(stage + "…", color = Mute, fontSize = 15.sp)
        }
    }
}

@Composable
private fun ResultScreen(
    before: Bitmap?, after: Bitmap?, kind: String, saving: Boolean,
    onNew: () -> Unit, onSave: () -> Unit
) {
    var holding by remember { mutableStateOf(false) }
    val shown = if (holding) before else after
    Column(
        Modifier.fillMaxSize().background(Color.Black.copy(0.82f))
            .statusBarsPadding().navigationBarsPadding().padding(16.dp)
    ) {
        Box(
            Modifier.weight(1f).fillMaxWidth().pointerInput(Unit) {
                detectTapGestures(onPress = { holding = true; tryAwaitRelease(); holding = false })
            },
            contentAlignment = Alignment.Center
        ) {
            if (shown != null) {
                Image(shown.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(
            (if (holding) "Original" else "Enhanced") + " · hold the photo to compare",
            color = Mute, fontSize = 14.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
        )
        Text(kind, color = Ink, fontSize = 14.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = onNew, shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Panel, contentColor = Ink),
                modifier = Modifier.weight(1f).height(54.dp)
            ) { Text("New photo") }
            Button(
                onClick = onSave, enabled = !saving, shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = AccentInk),
                modifier = Modifier.weight(1f).height(54.dp)
            ) { Text(if (saving) "Saving…" else "Save photo") }
        }
    }
}

private fun saveToGallery(ctx: Context, bmp: Bitmap): Boolean = try {
    val values = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, "Jashu_${System.currentTimeMillis()}.jpg")
        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Jashu Editing App")
        put(MediaStore.Images.Media.IS_PENDING, 1)
    }
    val resolver = ctx.contentResolver
    val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)!!
    resolver.openOutputStream(uri)!!.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
    values.clear()
    values.put(MediaStore.Images.Media.IS_PENDING, 0)
    resolver.update(uri, values, null, null)
    true
} catch (e: Exception) {
    false
}
