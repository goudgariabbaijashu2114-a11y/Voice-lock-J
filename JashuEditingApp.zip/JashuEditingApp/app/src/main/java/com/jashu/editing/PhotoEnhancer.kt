package com.jashu.editing

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Rect
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

class Output(val before: Bitmap, val after: Bitmap, val full: Bitmap, val kind: String)

private class Mask(val w: Int, val h: Int, val a: FloatArray)

object PhotoEnhancer {

    fun run(ctx: Context, uri: Uri, onStage: (String) -> Unit): Output =
        try {
            process(ctx, uri, 3840, onStage)
        } catch (e: OutOfMemoryError) {
            System.gc()
            process(ctx, uri, 2560, onStage)
        }

    private fun process(ctx: Context, uri: Uri, maxSide: Int, onStage: (String) -> Unit): Output {
        onStage("Opening your photo")
        val src = load(ctx, uri, maxSide)
        val w = src.width
        val h = src.height
        val n = w * h
        val before = preview(src)

        onStage("Looking for faces")
        val faces = detectFaces(src)
        val faceArea = faces.maxOfOrNull { (it.width().toLong() * it.height()).toFloat() } ?: 0f
        val portrait = faces.isNotEmpty() && faces.size <= 3 && faceArea / n > 0.012f

        val px = IntArray(n)
        src.getPixels(px, 0, w, 0, 0, w, h)

        onStage("Reading light and colour")
        val hist = IntArray(256)
        var sr = 0L; var sg = 0L; var sb = 0L; var cnt = 0; var sl = 0.0
        var i = 0
        while (i < n) {
            val p = px[i]
            val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
            val l = (0.299f * r + 0.587f * g + 0.114f * b).toInt()
            hist[l]++; sl += l; sr += r; sg += g; sb += b; cnt++
            i += 7
        }
        var lo = 0; var hi = 255; var acc = 0
        for (k in 0..255) { acc += hist[k]; if (acc > cnt * 0.005f) { lo = k; break } }
        acc = 0
        for (k in 255 downTo 0) { acc += hist[k]; if (acc > cnt * 0.005f) { hi = k; break } }
        if (hi - lo < 40) { lo = 0; hi = 255 }
        val scale = min(1.7f, 255f / (hi - lo))
        var mean = (((sl / cnt).toFloat() - lo) * scale / 255f).coerceIn(0.04f, 0.9f)
        if (faces.isNotEmpty()) {
            val f = faces.maxByOrNull { it.width() * it.height() }!!
            var fs = 0.0; var fc = 0
            var yy = f.top
            while (yy < f.bottom) {
                var xx = f.left
                while (xx < f.right) {
                    val p = px[yy * w + xx]
                    fs += 0.299f * ((p shr 16) and 255) + 0.587f * ((p shr 8) and 255) + 0.114f * (p and 255)
                    fc++; xx += 3
                }
                yy += 3
            }
            if (fc > 0) {
                val fm = (((fs / fc).toFloat() - lo) * scale / 255f).coerceIn(0.05f, 0.95f)
                mean = 0.6f * fm + 0.4f * mean
            }
        }
        val target = if (faces.isNotEmpty()) 0.5f else 0.46f
        val gamma = (ln(target) / ln(mean)).coerceIn(0.68f, 1.2f)

        val ar = sr.toFloat() / cnt; val ag = sg.toFloat() / cnt; val ab = sb.toFloat() / cnt
        val gray = (ar + ag + ab) / 3f
        fun wb(a: Float) = 1f + ((gray / max(a, 1f)).coerceIn(0.93f, 1.07f) - 1f) * 0.6f
        val gR = wb(ar); val gG = wb(ag); val gB = wb(ab)

        val lut = FloatArray(256)
        for (v in 0..255) {
            var t = ((v - lo) * scale / 255f).coerceIn(0f, 1f)
            t = t.pow(gamma)
            val sm = t * t * (3f - 2f * t)
            t = t * 0.68f + sm * 0.32f
            t += 0.035f * (1f - t) * (1f - t) * (1f - t)
            lut[v] = (t * 255f).coerceIn(0f, 255f)
        }

        onStage("Cleaning noise and adding detail")
        val bl = blurArray(src, 2)
        onStage(if (portrait) "Separating subject from background" else "Adding depth")
        val big = blurArray(src, 4)
        val mask: Mask? = if (portrait) segment(src) else null
        src.recycle()

        onStage("Colour grading in 4K")
        val fa = faces.toTypedArray()
        val cxm = w / 2f; val cym = h / 2f
        var idx = 0
        for (y in 0 until h) {
            val fy = if (mask != null) y * (mask.h - 1f) / max(1, h - 1) else 0f
            val dy = (y - cym) / cym
            for (x in 0 until w) {
                val p = px[idx]; val q = bl[idx]; val bg = big[idx]
                var r = ((p shr 16) and 255).toFloat()
                var g = ((p shr 8) and 255).toFloat()
                var b = (p and 255).toFloat()
                val qr = ((q shr 16) and 255).toFloat()
                val qg = ((q shr 8) and 255).toFloat()
                val qb = (q and 255).toFloat()
                var inFace = false
                for (f in fa) {
                    if (x >= f.left && x < f.right && y >= f.top && y < f.bottom) { inFace = true; break }
                }
                val ol = 0.299f * r + 0.587f * g + 0.114f * b
                val ql = 0.299f * qr + 0.587f * qg + 0.114f * qb
                val wgt = min(1f, abs(ol - ql) / 16f)
                val soft = if (inFace) 0.25f else 0.55f
                val sharp = if (inFace) 0.3f else 0.75f
                r = (r + (qr - r) * soft) * (1f - wgt) + (r + sharp * (r - qr)) * wgt
                g = (g + (qg - g) * soft) * (1f - wgt) + (g + sharp * (g - qg)) * wgt
                b = (b + (qb - b) * soft) * (1f - wgt) + (b + sharp * (b - qb)) * wgt

                val br = ((bg shr 16) and 255).toFloat()
                val bgg = ((bg shr 8) and 255).toFloat()
                val bb = (bg and 255).toFloat()
                val bigL = 0.299f * br + 0.587f * bgg + 0.114f * bb
                val cl = ((if (inFace) 0.10f else 0.24f) * (ol - bigL)).coerceIn(-30f, 30f)
                r += cl; g += cl; b += cl

                if (mask != null) {
                    val fx = x * (mask.w - 1f) / max(1, w - 1)
                    val m = smooth(0.3f, 0.75f, sample(mask, fx, fy))
                    if (m < 1f) {
                        r = br * 0.94f + (r - br * 0.94f) * m
                        g = bgg * 0.94f + (g - bgg * 0.94f) * m
                        b = bb * 0.94f + (b - bb * 0.94f) * m
                    }
                }

                r = lut[ci(r * gR)]; g = lut[ci(g * gG)]; b = lut[ci(b * gB)]

                val l = 0.299f * r + 0.587f * g + 0.114f * b
                val ch = (max(r, max(g, b)) - min(r, min(g, b))) / 255f
                val skin = r > 95f && g > 40f && b > 20f && r > g && r > b && (r - g) > 15f
                val sat = 1f + (if (skin || inFace) 0.04f else 0.2f) * (1f - ch)
                val dx = (x - cxm) / cxm
                val vg = 1f - 0.07f * (dx * dx + dy * dy)
                val rr = (l + (r - l) * sat) * 1.02f * vg
                val gg = (l + (g - l) * sat) * vg
                val b2 = (l + (b - l) * sat) * 0.98f * vg
                px[idx] = (255 shl 24) or (ci(rr) shl 16) or (ci(gg) shl 8) or ci(b2)
                idx++
            }
        }
        onStage("Finishing")
        val full = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        full.setPixels(px, 0, w, 0, 0, w, h)
        val kind = when {
            faces.isEmpty() -> "Scene photo"
            faces.size == 1 -> "Single portrait"
            faces.size == 2 -> "Two people"
            else -> "Group of ${faces.size}"
        } + (if (mask != null) " · background blurred" else "") + " · ${w}×${h}"
        return Output(before, preview(full), full, kind)
    }

    private fun ci(v: Float): Int = if (v < 0f) 0 else if (v > 255f) 255 else v.toInt()

    private fun smooth(a: Float, b: Float, x: Float): Float {
        val t = ((x - a) / (b - a)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    private fun sample(m: Mask, fx: Float, fy: Float): Float {
        val x0 = fx.toInt().coerceIn(0, m.w - 1); val x1 = min(x0 + 1, m.w - 1)
        val y0 = fy.toInt().coerceIn(0, m.h - 1); val y1 = min(y0 + 1, m.h - 1)
        val tx = fx - x0; val ty = fy - y0
        val a = m.a[y0 * m.w + x0] * (1 - tx) + m.a[y0 * m.w + x1] * tx
        val b = m.a[y1 * m.w + x0] * (1 - tx) + m.a[y1 * m.w + x1] * tx
        return a * (1 - ty) + b * ty
    }

    private fun blurArray(src: Bitmap, levels: Int): IntArray {
        val w = src.width; val h = src.height
        val made = ArrayList<Bitmap>()
        var cur = src
        repeat(levels) {
            val nb = Bitmap.createScaledBitmap(cur, max(1, cur.width / 2), max(1, cur.height / 2), true)
            made.add(nb); cur = nb
        }
        val up = Bitmap.createScaledBitmap(cur, w, h, true)
        val out = IntArray(w * h)
        up.getPixels(out, 0, w, 0, 0, w, h)
        made.forEach { if (it !== src) it.recycle() }
        if (up !== src) up.recycle()
        return out
    }

    private fun detectFaces(src: Bitmap): List<Rect> = try {
        val s = min(1f, 1024f / max(src.width, src.height))
        val small = if (s < 1f) Bitmap.createScaledBitmap(src, (src.width * s).toInt(), (src.height * s).toInt(), true) else src
        val det = FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .setMinFaceSize(0.08f).build()
        )
        val found = Tasks.await(det.process(InputImage.fromBitmap(small, 0)))
        det.close()
        found.map {
            val b = it.boundingBox
            val padX = (b.width() * 0.2f).toInt(); val padY = (b.height() * 0.2f).toInt()
            Rect(
                ((b.left - padX) / s).toInt().coerceIn(0, src.width - 1),
                ((b.top - padY) / s).toInt().coerceIn(0, src.height - 1),
                ((b.right + padX) / s).toInt().coerceIn(1, src.width),
                ((b.bottom + padY) / s).toInt().coerceIn(1, src.height)
            )
        }.filter { it.width() > 4 && it.height() > 4 }
    } catch (e: Exception) {
        emptyList()
    }

    private fun segment(src: Bitmap): Mask? = try {
        val s = min(1f, 640f / max(src.width, src.height))
        val small = if (s < 1f) Bitmap.createScaledBitmap(src, (src.width * s).toInt(), (src.height * s).toInt(), true) else src
        val seg = Segmentation.getClient(
            SelfieSegmenterOptions.Builder()
                .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE).build()
        )
        val m = Tasks.await(seg.process(InputImage.fromBitmap(small, 0)))
        seg.close()
        val bb = m.buffer
        bb.rewind()
        Mask(m.width, m.height, FloatArray(m.width * m.height) { bb.getFloat() })
    } catch (e: Exception) {
        null
    }

    private fun preview(b: Bitmap): Bitmap {
        val s = min(1f, 2048f / max(b.width, b.height))
        return if (s < 1f) Bitmap.createScaledBitmap(b, (b.width * s).toInt(), (b.height * s).toInt(), true)
        else b.copy(Bitmap.Config.ARGB_8888, false)
    }

    private fun load(ctx: Context, uri: Uri, maxSide: Int): Bitmap {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, bounds) }
        val longSide = max(bounds.outWidth, bounds.outHeight)
        var sample = 1
        while (longSide / (sample * 2) >= maxSide) sample *= 2
        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        var bmp = cr.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: throw IllegalStateException("Could not read this photo")
        val orient = try {
            cr.openInputStream(uri)!!.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            }
        } catch (e: Exception) { ExifInterface.ORIENTATION_NORMAL }
        val m = Matrix()
        when (orient) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(-90f); m.postScale(-1f, 1f) }
        }
        if (!m.isIdentity) {
            val t = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            if (t !== bmp) bmp.recycle()
            bmp = t
        }
        val s = maxSide.toFloat() / max(bmp.width, bmp.height)
        if (s < 1f) {
            val t = Bitmap.createScaledBitmap(bmp, (bmp.width * s).toInt(), (bmp.height * s).toInt(), true)
            if (t !== bmp) bmp.recycle()
            bmp = t
        }
        return bmp.copy(Bitmap.Config.ARGB_8888, true)
    }
}
