# Jashu Editing App

Android photo editor. Take a photo (or pick one) and it is enhanced automatically on the phone, offline, with up to 4K (3840 px) output. No prompts.

- Auto exposure, contrast, white balance, noise reduction, sharpening, clarity, colour grade
- ML Kit face detection: faces get gentler sharpening/denoising so skin texture stays natural; no face is altered, replaced or smoothed
- Portrait photos get a background blur (ML Kit segmentation)
- Hold the photo to compare with the original; Save writes a JPEG to Pictures/Jashu Editing App

## Get the APK from GitHub
1. Create a new GitHub repository and upload all files from this folder (keep the folder structure, including `.github`).
2. Open the **Actions** tab and wait for "Build APK" to finish (about 5 minutes).
3. Download `JashuEditingApp.apk` from **Releases > latest build** (or from the workflow run's Artifacts).
4. Open the APK on your phone and allow "Install unknown apps" when asked.

To rename the app, edit `app/src/main/res/values/strings.xml`.
